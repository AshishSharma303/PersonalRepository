﻿param(
	[Parameter(Mandatory=$true)] 
	[String]$RemoteVMCredName,
	
	[Parameter(Mandatory=$true)] 
	[String]$AzureSubscriptionId,
	
	[Parameter(Mandatory=$true)] 
	[String]$AzureOrgIdCredentialName,
	
	[Parameter(Mandatory=$true)] 
	[String]$ResourceGroupName,
	
	[Parameter(Mandatory=$true)] 
	[String]$VMName
	
)

$VMCredential = Get-AutomationPSCredential -Name $RemoteVMCredName

try
{    
    $IpAddress = .\Connect-AzureARMVMPS.ps1 -AzureSubscriptionId $AzureSubscriptionId -AzureOrgIdCredentialName $AzureOrgIdCredentialName -ResourceGroupName $ResourceGroupName -VMName $VMName  
    Write-Output "The IP Address is $IpAddress. Attempting to remote into the VM.."
    if($IpAddress -ne $null)
    {
          
            $sessionOptions = New-PSSessionOption -SkipCACheck -SkipCNCheck                
            Invoke-Command -ComputerName $IpAddress -Credential $VMCredential -UseSSL -SessionOption $sessionOptions -ScriptBlock { 
		    #Code to be executed in the remote session goes here
            $hostname = hostname
            Write-Output "Hostname : $hostname"
            }

    }
}
catch
{
    Write-Output "Could not remote into the VM"
    Write-Output "Ensure that the VM is running and that the correct VM credentials are used to remote"
    Write-Output "Error in getting the VM Details.: $($_.Exception.Message) "
}